from django.shortcuts import render
from django.http import HttpResponse

# Create your views here.
def index(request):
    return render(request,"index.html")

def companies(request):
    return render(request,"companies.html")

def login(request):
    return render(request,"login.html")

def recurments(request):
    return render(request,"recurments.html")

def search_jobs(request):
    return render(request,"search jobs.html")

def services(request):
    return render(request,"services.html")
